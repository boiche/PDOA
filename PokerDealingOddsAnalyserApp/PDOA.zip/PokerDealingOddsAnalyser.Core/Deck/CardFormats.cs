﻿namespace PokerDealingOddsAnalyser.Core.Deck
{
    public enum CardFormats
    {
        FullDetailed, //King-Diamonds
        Shortened, //Kd
    }
}
