﻿namespace PokerDealingOddsAnalyserApp
{
    partial class HistoryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.handHistoryGrid = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.handViewTemplateBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.timeDealtDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dealNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dealsCountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.playerHandDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.handViewTemplateBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.handHistoryGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.handViewTemplateBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.handViewTemplateBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // handHistoryGrid
            // 
            this.handHistoryGrid.AllowUserToAddRows = false;
            this.handHistoryGrid.AllowUserToDeleteRows = false;
            this.handHistoryGrid.AutoGenerateColumns = false;
            this.handHistoryGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.handHistoryGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.timeDealtDataGridViewTextBoxColumn,
            this.dealNumberDataGridViewTextBoxColumn,
            this.dealsCountDataGridViewTextBoxColumn,
            this.playerHandDataGridViewTextBoxColumn});
            this.handHistoryGrid.DataSource = this.handViewTemplateBindingSource1;
            this.handHistoryGrid.Location = new System.Drawing.Point(2, 2);
            this.handHistoryGrid.Name = "handHistoryGrid";
            this.handHistoryGrid.ReadOnly = true;
            this.handHistoryGrid.RowHeadersWidth = 51;
            this.handHistoryGrid.RowTemplate.Height = 24;
            this.handHistoryGrid.Size = new System.Drawing.Size(1489, 624);
            this.handHistoryGrid.TabIndex = 0;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Column1";
            this.Column1.MinimumWidth = 6;
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 125;
            // 
            // handViewTemplateBindingSource
            // 
            this.handViewTemplateBindingSource.DataSource = typeof(PokerDealingOddsAnalyser.Core.Logging.HandViewTemplate);
            // 
            // timeDealtDataGridViewTextBoxColumn
            // 
            this.timeDealtDataGridViewTextBoxColumn.DataPropertyName = "TimeDealt";
            this.timeDealtDataGridViewTextBoxColumn.HeaderText = "TimeDealt";
            this.timeDealtDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.timeDealtDataGridViewTextBoxColumn.Name = "timeDealtDataGridViewTextBoxColumn";
            this.timeDealtDataGridViewTextBoxColumn.ReadOnly = true;
            this.timeDealtDataGridViewTextBoxColumn.Width = 125;
            // 
            // dealNumberDataGridViewTextBoxColumn
            // 
            this.dealNumberDataGridViewTextBoxColumn.DataPropertyName = "DealNumber";
            this.dealNumberDataGridViewTextBoxColumn.HeaderText = "DealNumber";
            this.dealNumberDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.dealNumberDataGridViewTextBoxColumn.Name = "dealNumberDataGridViewTextBoxColumn";
            this.dealNumberDataGridViewTextBoxColumn.ReadOnly = true;
            this.dealNumberDataGridViewTextBoxColumn.Width = 125;
            // 
            // dealsCountDataGridViewTextBoxColumn
            // 
            this.dealsCountDataGridViewTextBoxColumn.DataPropertyName = "DealsCount";
            this.dealsCountDataGridViewTextBoxColumn.HeaderText = "DealsCount";
            this.dealsCountDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.dealsCountDataGridViewTextBoxColumn.Name = "dealsCountDataGridViewTextBoxColumn";
            this.dealsCountDataGridViewTextBoxColumn.ReadOnly = true;
            this.dealsCountDataGridViewTextBoxColumn.Width = 125;
            // 
            // playerHandDataGridViewTextBoxColumn
            // 
            this.playerHandDataGridViewTextBoxColumn.DataPropertyName = "PlayerHand";
            this.playerHandDataGridViewTextBoxColumn.HeaderText = "PlayerHand";
            this.playerHandDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.playerHandDataGridViewTextBoxColumn.Name = "playerHandDataGridViewTextBoxColumn";
            this.playerHandDataGridViewTextBoxColumn.ReadOnly = true;
            this.playerHandDataGridViewTextBoxColumn.Width = 125;
            // 
            // handViewTemplateBindingSource1
            // 
            this.handViewTemplateBindingSource1.DataSource = typeof(PokerDealingOddsAnalyser.Core.Logging.HandViewTemplate);
            // 
            // HistoryForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1494, 630);
            this.Controls.Add(this.handHistoryGrid);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "HistoryForm";
            this.Text = "HistoryForm";
            this.Shown += new System.EventHandler(this.LoadHands);
            ((System.ComponentModel.ISupportInitialize)(this.handHistoryGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.handViewTemplateBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.handViewTemplateBindingSource1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.BindingSource handViewTemplateBindingSource;
        private System.Windows.Forms.DataGridView handHistoryGrid;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn timeDealtDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dealNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dealsCountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn playerHandDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource handViewTemplateBindingSource1;
    }
}